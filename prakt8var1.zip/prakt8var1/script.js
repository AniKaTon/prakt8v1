

document.getElementById("ler").addEventListener("click", function(e) {

document.getElementById('tex').innerHTML = ' Появляется какой то текст))))';

let target = e && e.target || event.srcElement;

})


tr= true;
document.getElementById("ish").addEventListener("click", function(e) {


if(tr==true){
	
let m = document.getElementsByTagName("h1");
for(let i = 0; i < m.length; i++) { 
m[i].style.fontStyle= "italic";
}
let m1 = document.getElementsByTagName("h2");
for(let i = 0; i < m1.length; i++) { 
m1[i].style.fontStyle= "italic";}
tr=false;
Exit;
}
if(tr==false){


let m = document.getElementsByTagName("h1");
for(let i = 0; i < m.length; i++) { 
m[i].style.fontStyle= "normal";
}
let m1 = document.getElementsByTagName("h2");
for(let i = 0; i < m1.length; i++) { 
m1[i].style.fontStyle= "normal";
tr=true;
}

}
});


